import "./navbar.css"
import { useNavigate } from "react-router-dom";


const Navbar = () => {
  const naviga = useNavigate();
  const handleSearch = () => {
    naviga("/");
  };
  const handleSearch1 = () => {
    naviga("/login");
  };
  
  return (
    <div className="navbar">
      <div className="navContainer">
        <span className="logo" onClick={handleSearch}>Way2PG</span>
        <div className="navItems">
          <button className="navButton" onClick={handleSearch1}>Sign-Up</button>
          <button className="navButton" onClick={handleSearch1}>Login</button>
        </div>
      </div>
    </div>
  )
}

export default Navbar