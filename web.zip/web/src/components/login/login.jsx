import "./login.css"
import { useNavigate } from "react-router-dom";


const Login = () => {

    const switchers = [...document.querySelectorAll('.switcher')]

    switchers.forEach(item => {
        item.addEventListener('click', function () {
            switchers.forEach(item => item.parentElement.classList.remove('is-active'))
            this.parentElement.classList.add('is-active')
        })
    })

    // const naviga = useNavigate();
    // const handleSearch = () => {
    //     naviga("/login");
    // };

    return (
        <>
            <div class="main">
                <input type="checkbox" id="chk" aria-hidden="true" />

                <div class="signup">
                    <form>
                        <label className="lb12" htmlFor="chk" aria-hidden="true">Sign up</label>
                        <input className="inp12" type="text" name="txt" placeholder="User name" required="" />
                        <input className="inp12" type="email" name="email" placeholder="Email" required="" />
                        <input className="inp12" type="password" name="pswd" placeholder="Password" required="" />
                        <button className="bt12">Sign up</button>
                    </form>
                </div>

                <div class="login">
                    <form>
                        <label className="lb12" htmlFor="chk" aria-hidden="true">Login</label>
                        <input className="inp12" type="email" name="email" placeholder="Email" required="" />
                        <input className="inp12" type="password" name="pswd" placeholder="Password" required="" />
                        <button className="bt12">Login</button>
                    </form>
                </div>
            </div>

        </>
    )
}

export default Login